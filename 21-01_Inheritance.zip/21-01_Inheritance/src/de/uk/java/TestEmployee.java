package de.uk.java;

import de.uk.java.employees.*;

public class TestEmployee {
	 
	   public static void main(String[] args){
	      Employee e = new Employee();
	      e.setName("Emily");
	      e.setAge(45);
	      e.setSalary(65520.00);
	 
	      Programmer p = new Programmer();
	      p.setName("Ben");
	      p.setAge(37);
	      p.setSalary(77435.00);
	      p.setLanguage("Java");
	 
//	      Artist d = new Artist();
//	      d.name = "Jack";
//	      d.age = 28;
//	      d.salary = 45000.00;
//	      d.artTool = "My SQL";
	 
	      p.raise(10);
	      e.printData();
	      p.printData();
//	      d.printData();
	   }
	}