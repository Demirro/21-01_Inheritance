package de.uk.java.employees;

public class Programmer extends Employee {

	private String language;

	public Programmer(String name, int age, double salary, String language) {
		super(name, age, salary);
		this.language = language;
	}

	public Programmer() {
	}

	public void printData() {
		super.printData();
		System.out.println("language: " + getLanguage());
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
}
