package de.uk.java.employees;

public class Employee {
	private String name;
	private int age;
	private double salary;

	public Employee(String name, int age, double salary) {
		this.name = name;
		this.age = age;
		this.salary = salary;
	}

	public Employee() {
	};

	public void printData() {
		System.out.println("name: " + getName());
		System.out.println("age: " + getAge());
		System.out.println("salary: " + getSalary());

	}

	public void raise(int percent) {
		System.out.println("Current salary: " + getSalary());
		// this.setSalary(this.getSalary() + (this.getSalary() * (percent/100.0)));
		this.salary += (this.salary * (percent / 100.0));
		System.out.println("New salary: " + getSalary());
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
}
