package de.uk.java.employees;

public class Artist extends Employee {

	String artTool;

	public Artist(String name, int age, double salary, String artTool) {
		super(name, age, salary);
		this.artTool = artTool;
	}

	public Artist() {
	}

	public void printData() {
		super.printData();
		System.out.println("Art Tool: " + artTool);
	}
}
