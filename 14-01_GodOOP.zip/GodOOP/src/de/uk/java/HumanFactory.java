package de.uk.java;

public class HumanFactory {

	public static void main(String[] args) {
		/* zwei neue Instanzen.
		 * Ein Männlein und ein Weiblein
		 * Beide sind Instanzen vom jeweiligen Geschlecht
		 * aber auch von der Klasse Human
		 */
		Male adam = new Male("Adam", 23, 175, false);
		Female eve = new Female("Eve", 23, 170, false);
	
		/* sleep und think sind Methoden der Human-Klasse
		 * auf welche aber Adam als Male dennoch zugreifen kann
		 * denn Male ist eine Subklasse von Human und erbt alle ihre Eigenschaften und Methoden
		 * Entsprechend können sowohl Adam als auch Eva diese Methoden ausführen
		 */
		adam.sleep(5);
		System.out.println(adam.think());
		eve.walk();
	
		/* Hier rufen wir eine für die Klasse Female spezifische Methode auf
		 * Frauen können neue Menschen auf die Welt bringen
		 * Diese müssen auch einem Objekt (bsp. Male max) zugewiesen werden
		 * Adam (bzw. die Klasse Male) besitzt diese Methode nicht
		 */
		Male max = eve.giveBirthToMale("max", 51, true);
		Female anna = eve.giveBirthToFemale("anna", 50, true);
		
		// Hier wird eine Methode aufgerufen, die nur in der Klasse Male existiert
		adam.peeStandingUp();
	}
}
